import{j as e}from"./index-Ww5WxdXc.js";import{c as m}from"./Card-rRtVtR6y.js";const n=({size:s="md",className:r})=>{const o={sm:"w-4 h-4",md:"w-6 h-6",lg:"w-8 h-8"};return e.jsx("div",{className:m("animate-spin rounded-full border-b-2 border-primary-600",o[s],r)})};export{n as L};
//# sourceMappingURL=LoadingSpinner-mxC3s6UF.js.map
