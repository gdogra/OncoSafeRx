const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index-CBDHqVsd.js","assets/index-Ww5WxdXc.js","assets/index-BmrbClYN.css","assets/index-CnyDuYXe.js"])))=>i.map(i=>d[i]);
import{_ as n}from"./index-Ww5WxdXc.js";async function i(t){try{(await n(()=>import("./index-CBDHqVsd.js"),__vite__mapDeps([0,1,2,3]))).init({dsn:t,tracesSampleRate:.1,integrations:[],environment:"production",release:"1.0.0"})}catch{}}export{i as initSentry};
//# sourceMappingURL=sentry-Xe5kbaz-.js.map
